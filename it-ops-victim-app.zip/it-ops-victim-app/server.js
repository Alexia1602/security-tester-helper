const express = require('express');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./src/routes/api');

const app = express();
const PORT = 5000;

// Enable Cross-Origin Resource Sharing for the Electron Main Application dashboard
app.use(cors({ origin: '*' }));
app.use(express.json());

// Serve the static frontend console assets
app.use(express.static(path.join(__dirname, 'public')));

// Mount the modular API router channels
app.use('/api', apiRoutes);

app.listen(PORT, () => {
  console.log(`================================================================`);
  console.log(`🛡️  Target Cyber Threat Victim environment successfully launched.`);
  console.log(`🌐 Control Panel UI is live at: http://localhost:${PORT}`);
  console.log(`================================================================`);
});