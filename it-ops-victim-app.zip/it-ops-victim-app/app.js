const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const app = express();
const PORT = 5000;

app.use(cors({ origin: '*' }));

app.use(express.json());

// 🛡️ SECURITY HOT-PATCH SWITCH (CONTROLLED BY THE MAIN APP)
let SECURITY_PATCH_ACTIVE = false;

// 💾 IN-MEMORY DATABASE (PII & SENSITIVE ADMINISTRATIVE LOOT)
const database = {
  tickets: [
    { id: "101", customer: "Standard Client", title: "Office printer offline", description: "The printer in Room 4 is not responding to network ping requests.", severity: "low" },
    { id: "102", customer: "CONFIDENTIAL System Admin", title: "Infrastructure Key Rotation", description: "SECURITY NOTICE: The temporary authentication token for the IT Ops network diagnostic panel is: SECRET_ADMIN_TOKEN_2026", severity: "critical" }
  ],
  sensitive_infrastructure_vault: [
    { host: "core-db-production", credentials: "root:DB_Password_Secure_99!", role: "Government Records DB" },
    { host: "backup-cloud-vault", credentials: "admin:CloudAWS_Key_2026#", role: "Stocare Fișiere PII Vault" }
  ]
};

// 🌐 INTERACTIVE MINIMALIST FRONTEND (UI)
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>IT Operations Portal - Target Victim</title>
        <style>
          body { font-family: monospace; background: #0f172a; color: #38bdf8; padding: 20px; }
          .container { max-width: 650px; margin: 0 auto; border: 1px solid #1e293b; padding: 20px; background: #020617; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.5); }
          input, button { background: #1e293b; color: white; border: 1px solid #38bdf8; padding: 8px; font-family: monospace; border-radius: 6px; outline: none; }
          button { cursor: pointer; background: #0369a1; font-weight: bold; transition: background 0.2s; }
          button:hover { background: #0284c7; }
          .box { border: 1px dashed #334155; padding: 15px; margin: 15px 0; background: #0f172a; border-radius: 8px; }
          .status-patch { color: #f43f5e; font-weight: bold; }
          .status-patch.active { color: #10b981; }
          h2, h3 { margin-top: 0; color: #f8fafc; }
          pre { background: #020617; padding: 10px; border: 1px solid #1e293b; border-radius: 6px; max-height: 200px; overflow-y: auto; }
        </style>
      </head>
      <body>
        <div class="container">
          <h2>🛡️ Internal IT Operations & Support Portal (Target Environment)</h2>
          <p>Security Patch Status: <span id="patchStatus" class="status-patch">DISABLED (Vulnerable)</span></p>
          
          <div class="box">
            <h3>🔍 Step 1: View Support Ticket (IDOR Vulnerability)</h3>
            <label>Ticket ID: </label>
            <input type="text" id="ticketId" value="101" style="width: 60px; text-align: center;">
            <button onclick="viewTicket()">Fetch Ticket</button>
            <pre id="ticketResult" style="color: #94a3b8; margin-top: 10px;">Click fetch to execute request...</pre>
          </div>

          <div class="box">
            <h3>🔒 Step 2: Diagnostic Panel Gatekeeper</h3>
            <input type="text" id="adminToken" placeholder="Enter Administrative Token ID" style="width: 280px;">
            <button onclick="checkAdmin()">Verify Token</button>
            <pre id="adminResult" style="color: #94a3b8; margin-top: 10px;">Awaiting verification...</pre>
          </div>

          <div class="box" id="diagnosticBox" style="display:none; border-color: #f43f5e;">
            <h3>⚡ Step 3: Network Diagnostics Utility (Command Injection)</h3>
            <p style="color: #94a3b8; font-size: 12px;">Execute a standard ICMP ping check on an internal infrastructure asset node:</p>
            <input type="text" id="targetIp" value="127.0.0.1" style="width: 180px;">
            <button onclick="executePing()">Run Diagnostics</button>
            <pre id="pingResult" style="color: #a7f3d0; background: #020617; padding: 10px;"></pre>
          </div>
        </div>

        <script>
          const API_URL = 'http://localhost:5000';

          // Dynamic polling to watch the core hot-patch status from the main dashboard
          setInterval(async () => {
            try {
              const res = await fetch(API_URL + '/api/debug/patch-status');
              const data = await res.json();
              const statusEl = document.getElementById('patchStatus');
              if(data.active) {
                statusEl.innerText = "ENABLED (Patched & Secure)";
                statusEl.className = "status-patch active";
              } else {
                statusEl.innerText = "DISABLED (Vulnerable Environment)";
                statusEl.className = "status-patch";
              }
            } catch(e) {}
          }, 1000);

          async function viewTicket() {
            const id = document.getElementById('ticketId').value;
            const res = await fetch(API_URL + '/api/v1/tickets/' + id);
            const data = await res.json();
            document.getElementById('ticketResult').innerText = JSON.stringify(data, null, 2);
          }

          async function checkAdmin() {
            const token = document.getElementById('adminToken').value;
            if(token === "SECRET_ADMIN_TOKEN_2026") {
              document.getElementById('adminResult').innerText = "✔️ Authentication Successful! Elevated diagnostic utility unlocked.";
              document.getElementById('diagnosticBox').style.display = "block";
            } else {
              document.getElementById('adminResult').innerText = "❌ Access Denied: Cryptographic token layout missing or invalid.";
              document.getElementById('diagnosticBox').style.display = "none";
            }
          }

          async function executePing() {
            const ip = document.getElementById('targetIp').value;
            document.getElementById('pingResult').innerText = "Processing automated platform infrastructure check. Please wait...";
            
            const res = await fetch(API_URL + '/api/v1/system/diagnostic', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ip })
            });
            const data = await res.json();
            document.getElementById('pingResult').innerText = data.output || data.error;
          }
        </script>
      </body>
    </html>
  `);
});

// ==========================================
// 🚨 VULNERABLE ENDPOINT 1: IDOR (CWE-284)
// ==========================================
app.get('/api/v1/tickets/:id', (req, res) => {
  const { id } = req.params;
  
  // IF REMEDIATED: Enforce authorization layer checks
  if (SECURITY_PATCH_ACTIVE) {
    if (id !== "101") {
      return res.status(403).json({ error: "Authorization Error: Current security context lacks permissions to view administrative assets." });
    }
  }

  const ticket = database.tickets.find(t => t.id === id);
  if (!ticket) return res.status(404).json({ error: "Target support ticket entity not found." });
  res.json(ticket);
});

// ==========================================
// 🚨 VULNERABLE ENDPOINT 2: OS COMMAND INJECTION (CWE-78)
// ==========================================
app.post('/api/v1/system/diagnostic', (req, res) => {
  console.log("Cerere diagnostic primită:", req.body);
  const { ip } = req.body;

  if (!ip) return res.status(400).json({ error: "Required structural parameter 'ip' is missing." });

  // IF REMEDIATED: Sanitize input parameters via a strict whitelist Regular Expression
  if (SECURITY_PATCH_ACTIVE) {
    const ipRegex = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/;
    if (!ipRegex.test(ip.trim())) {
      return res.status(400).json({ error: "Malicious payload signature detected! Unsanitised character injection blocked." });
    }
  }

  // SYSTEM SHELL CONCATENATION (High-Risk Pattern)
  let command = `ping -c 1 ${ip}`;
  if (process.platform === "win32") {
    command = `ping -n 1 ${ip}`;
  }

  exec(command, (err, stdout, stderr) => {
    if (err && !stdout) {
      return res.status(500).json({ error: "Runtime utility exception: " + stderr });
    }
    
    // Check if pivoting/chaining characters exist to simulate real-time exfiltration dump
    if (ip.includes(";") || ip.includes("&") || ip.includes("|")) {
      return res.json({ 
        output: stdout + "\n\n[☠️ CRITICAL METASPLOIT SIMULATION - VAULT RECORDS EXFILTRATED]:\n" + JSON.stringify(database.sensitive_infrastructure_vault, null, 2)
      });
    }

    res.json({ output: stdout || stderr });
  });
});

// =========================================================================
// 🔄 REMEDIATION & STATE INTERACTION CHANNELS (FOR MAIN TESTING HELPER)
// =========================================================================
app.get('/api/debug/patch-status', (req, res) => {
  res.json({ active: SECURITY_PATCH_ACTIVE });
});

app.post('/api/debug/toggle-patch', (req, res) => {
  const { active } = req.body;
  SECURITY_PATCH_ACTIVE = !!active;
  console.log(`[SYS ADMIN ALERT]: Environment defense state toggled to: ${SECURITY_PATCH_ACTIVE}`);
  res.json({ success: true, patch_active: SECURITY_PATCH_ACTIVE });
});

app.listen(PORT, () => {
  console.log(`🚀 Vulnerable IT Operations Environment running on http://localhost:${PORT}`);
});