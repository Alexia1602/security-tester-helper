const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const authController = require('../controllers/authController');
const systemController = require('../controllers/systemController');
const security = require('../config/security');

// Business Logic Functional Endpoints
router.get('/v1/tickets/:id', ticketController.getTicketById);
router.post('/v1/auth/verify-admin', authController.verifyAdminToken);
router.post('/v1/system/diagnostic', systemController.runNetworkDiagnostic);

// 🚨 NEW VULNERABLE ENDPOINT: Information Disclosure (CWE-200)
router.get('/v1/system/debug-logs', systemController.getDebugLogs);

// Orchestration & Inter-App Control Endpoints (For the Main Testing Helper app)
router.get('/debug/patch-status', (req, res) => {
  res.json({ active: security.isPatched() });
});

router.post('/debug/toggle-patch', (req, res) => {
  const { active } = req.body;
  security.setPatchState(active);
  res.json({ success: true, patch_active: security.isPatched() });
});

module.exports = router;