
const dataStore = {
  tickets: [
    { 
      id: "101", 
      customer: "External Client Tier-1", 
      title: "VPN connection drops frequently", 
      description: "When connecting from remote offices, the session invalidates after 5 minutes.", 
      severity: "medium" 
    },
    { 
      id: "102", 
      customer: "Internal System Administrator", 
      title: "Urgent: Infrastructure Credential Leak", 
      description: "CRITICAL CONFIGURATION NOTICE: The emergency access token for the administrative terminal is temporarily set to: SECRET_ADMIN_TOKEN_2026. Please rotate this immediately.", 
      severity: "critical" 
    }
  ],
  users: [
    { username: "operator_john", role: "support_tier_1", active: true },
    { username: "sec_admin", role: "global_infrastructure_admin", active: true }
  ],
  sensitive_vault: [
    { asset_id: "core-db-01", host: "10.0.4.15", credentials: "db_admin:K8s_Cluster_Pass_2026!!", description: "Production Database containing PII and financial ledger logs." },
    { asset_id: "cloud-backup-node", host: "10.0.9.82", credentials: "aws_iam_backup_user:AWS_Secret_Key_991823", description: "Offsite automated backup node container hashes." }
  ]
};

module.exports = dataStore;