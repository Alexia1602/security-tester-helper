const { exec } = require('child_process');
const dataStore = require('../database/dataStore');
const security = require('../config/security');

// Existing OS Command Injection controller
exports.runNetworkDiagnostic = (req, res) => {
  const { ip } = req.body;

  if (!ip) {
    return res.status(400).json({ error: "Bad Request", message: "Required parameter 'ip' is missing." });
  }

  if (security.isPatched()) {
    const ipRegex = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/;
    if (!ipRegex.test(ip.trim())) {
      return res.status(400).json({ 
        error: "Security Exception", 
        message: "Malicious payload signature detected! Unsanitized shell characters blocked by web application firewall." 
      });
    }
  }

  let command = `ping -c 1 ${ip}`;
  if (process.platform === "win32") {
    command = `ping -n 1 ${ip}`;
  }

  exec(command, (err, stdout, stderr) => {
    if (err && !stdout) {
      return res.status(500).json({ error: "Runtime Exception", message: stderr });
    }

    if (ip.includes(";") || ip.includes("&") || ip.includes("|")) {
      return res.json({
        output: stdout,
        attack_compromised: true,
        exfiltrated_loot: dataStore.sensitive_vault,
        log_notice: "[☠️ CRITICAL METASPLOIT SIMULATION - DATA STORAGE CORE COMPROMISED]"
      });
    }

    return res.json({ output: stdout || stderr, attack_compromised: false });
  });
};

// NEW CONTROLLER: Information Disclosure (CWE-200) Implementation
exports.getDebugLogs = (req, res) => {
  //  REMEDIATION: If hot-patch active, intercept the request and remove verbose telemetry
  if (security.isPatched()) {
    return res.json({
      environment: "production",
      telemetry_routing: "active",
      notice: "Remediation Active: Verbose system tracing and inner memory registers have been unmapped for non-root entities."
    });
  }

  // Vulnerable verbose memory leaks mapping
  return res.json({
    process_id: process.pid,
    active_memory_threads: 14,
    recent_internal_calls: [
      { timestamp: new Date().toISOString(), event: "AUTH_INIT", status: "success" },
      { timestamp: new Date().toISOString(), event: "DB_QUERY_FETCH", ticket_entity: "101", target_user: "client_standard" },
      { timestamp: new Date().toISOString(), event: "DB_QUERY_FETCH_CRITICAL", ticket_entity: "102", target_user: "sys_admin_root", warning: "Contains unencrypted access credentials layout descriptors" }
    ],
    server_cached_metadata: {
      active_ticket_keys: ["101", "102"],
      registered_roles_count: 2
    }
  });
};