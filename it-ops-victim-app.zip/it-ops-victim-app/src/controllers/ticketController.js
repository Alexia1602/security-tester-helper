const dataStore = require('../database/dataStore');
const security = require('../config/security');

exports.getTicketById = (req, res) => {
  const { id } = req.params;

  if (security.isPatched()) {
    if (id !== "101") {
      return res.status(403).json({ 
        error: "Access Denied", 
        message: "Authorization Error: Current session security context lacks privileges to inspect administrative tickets." 
      });
    }
  }

  const ticket = dataStore.tickets.find(t => t.id === id);
  if (!ticket) {
    return res.status(404).json({ error: "Not Found", message: "Target support ticket entity not found." });
  }

  return res.json(ticket);
};