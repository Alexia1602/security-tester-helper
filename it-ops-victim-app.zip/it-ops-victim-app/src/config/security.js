let SECURITY_PATCH_ACTIVE = false;

module.exports = {
  isPatched: () => SECURITY_PATCH_ACTIVE,
  setPatchState: (state) => {
    SECURITY_PATCH_ACTIVE = !!state;
  }
};